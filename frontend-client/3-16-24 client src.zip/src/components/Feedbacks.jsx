import React from 'react'

const Feedbacks = () => {
  return (
    <div>Feedbacks</div>
  )
}

export default Feedbacks