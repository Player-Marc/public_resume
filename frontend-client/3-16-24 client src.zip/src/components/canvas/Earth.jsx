import React from 'react'

const Earth = () => {
  return (
    <div>Earth</div>
  )
}

export default Earth